.. ltpdoctest documentation master file, created by
   sphinx-quickstart on Wed Jan 14 22:35:55 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: intro.rst

.. include:: news.rst

目录
=====

.. toctree::
    :maxdepth: 2

    begin
    install
    ltptest
    api
    ltpserver
    otherlanguage
    train
    theory
    faq
    paper
    appendix
    license


索引及表格
==================

* :ref:`genindex`
* :ref:`search`

