# Training Suite for LTP

for running all the training process, just execute

```
./rock.sh
```

after compilation
